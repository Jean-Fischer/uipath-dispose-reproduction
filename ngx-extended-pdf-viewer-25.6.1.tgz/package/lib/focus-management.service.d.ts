import * as i0 from "@angular/core";
export declare class FocusManagementService {
    private previousActiveElement;
    private ariaLiveRegion;
    private activeDialogId;
    private keydownHandler;
    constructor();
    /**
     * Initializes a hidden aria-live region for screen reader announcements
     */
    private initializeAriaLiveRegion;
    /**
     * Announces a message to screen readers via aria-live region
     * @param message The message to announce
     */
    announce(message: string): void;
    /**
     * Moves focus to the first focusable element within a dialog
     * @param dialogId The ID of the dialog element
     * @param announceMessage Optional message to announce when dialog opens
     * @param buttonId Optional ID of the button that triggered the dialog (for reliable focus return)
     */
    moveFocusToDialog(dialogId: string, announceMessage?: string, buttonId?: string): void;
    /**
     * Sets up focus cycling so that tabbing past the last element returns to the toolbar
     * @param dialog The dialog element
     */
    private setupFocusCycling;
    /**
     * Cleans up focus cycling event listeners
     */
    private cleanupFocusCycling;
    /**
     * Gets all focusable elements within a container
     * @param container The container element
     * @returns Array of focusable elements
     */
    private getAllFocusableElements;
    /**
     * Returns focus to the previously focused element (typically the button that opened the dialog)
     * @param announceMessage Optional message to announce when dialog closes
     */
    returnFocusToPrevious(announceMessage?: string): void;
    /**
     * Finds the first focusable element within a container
     * @param container The container element to search within
     * @returns The first focusable element or null
     */
    private findFirstFocusableElement;
    /**
     * Checks if an element is visible
     * @param element The element to check
     * @returns True if the element is visible
     */
    private isVisible;
    static ɵfac: i0.ɵɵFactoryDeclaration<FocusManagementService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<FocusManagementService>;
}
