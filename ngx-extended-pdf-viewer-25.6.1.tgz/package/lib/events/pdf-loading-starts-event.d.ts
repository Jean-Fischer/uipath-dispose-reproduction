export interface PdfLoadingStartsEvent {
}
