export interface AnnotationEditorEvent {
    source: any;
    type: 'altTextChanged' | 'removed' | 'sizeChanged' | 'commit' | 'fontSizeChanged' | 'colorChanged' | 'thicknessChanged' | 'opacityChanged' | 'bezierPathChanged' | 'moved' | 'imageAdded';
    editorType: string;
    value: any;
    previousValue?: any;
}
