import { NgZone } from '@angular/core';
import { IPDFViewerApplication } from '../options/pdf-viewer-application';
import * as i0 from "@angular/core";
/**
 * Pure Angular service for iOS Safari pinch-to-zoom optimization
 * Works by dynamically adjusting the maxCanvasPixels option during touch gestures
 * This approach is compatible with the existing mypdf.js MaxCanvasSize class
 */
export declare class IOSCanvasOptimizationService {
    private ngZone;
    private PDFViewerApplication;
    private isInitialized;
    private isPinching;
    private cooldownTimer;
    private originalMaxCanvasPixels;
    private reducedMaxCanvasPixels;
    private readonly cooldownDuration;
    private readonly reductionFactor;
    private readonly iosMaxCanvasPixels;
    constructor(ngZone: NgZone);
    /**
     * Initialize the service with PDFViewerApplication
     * Called from NgxExtendedPdfViewerComponent.initialize()
     */
    initialize(pdfViewerApplication: IPDFViewerApplication): void;
    private getDefaultCanvasSize;
    private setupTouchListeners;
    private onPinchStart;
    private onPinchEnd;
    private startCooldown;
    private clearCooldown;
    private updateCanvasSize;
    private triggerVisiblePageRerender;
    private isPageVisible;
    /**
     * Get current canvas size setting
     */
    getCurrentCanvasSize(): number;
    /**
     * Check if currently in pinch mode
     */
    isPinchingActive(): boolean;
    /**
     * Manually override the canvas size (for advanced users)
     */
    setCanvasSize(maxCanvasPixels: number): void;
    /**
     * Cleanup when service is destroyed
     */
    destroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<IOSCanvasOptimizationService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<IOSCanvasOptimizationService>;
}
