export declare class PositioningService {
    private static readonly DOORHANGER_OFFSET;
    private static readonly TOOLBAR_MARGIN;
    positionPopupBelowItsButton(buttonId: string, popupId: string): void;
    private findVisibleButton;
    private getPopupElement;
    private applyPopupPositioning;
    private setBasicPopupStyles;
    private setHorizontalPosition;
    private setVerticalPosition;
}
