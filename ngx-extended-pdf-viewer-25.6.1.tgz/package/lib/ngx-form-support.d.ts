import { ChangeDetectorRef, EventEmitter, NgZone } from '@angular/core';
import { FormDataType } from './ngx-extended-pdf-viewer.component';
import { IPDFViewerApplication } from './options/pdf-viewer-application';
export type HtmlFormElement = HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement;
export declare class NgxFormSupport {
    /** Maps the internal ids of the annotations of pdf.js to their field name */
    private formIdToFullFieldName;
    private formIdToField;
    private radioButtons;
    formData: FormDataType;
    initialFormDataStoredInThePDF: FormDataType;
    formDataChange: EventEmitter<FormDataType>;
    private PDFViewerApplication;
    ngZone: NgZone;
    cdr: ChangeDetectorRef;
    reset(): void;
    registerFormSupportWithPdfjs(PDFViewerApplication: IPDFViewerApplication): void;
    private registerAcroformField;
    private registerXFAField;
    private getValueOfASelectField;
    private getFormValueFromAngular;
    private findXFAName;
    private findFullXFAName;
    private updateAngularFormValueCalledByPdfjs;
    private doUpdateAngularFormValue;
    updateFormFieldsInPdfCalledByNgOnChanges(previousFormData: Object): void;
    private setFieldValueAndUpdateAnnotationStorage;
    private populateSelectField;
    private findFormIdsFromFieldName;
    private findRadioButtonGroup;
}
