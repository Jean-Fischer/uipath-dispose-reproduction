export declare enum AnnotationMode {
    DISABLE = 0,
    ENABLE = 1,
    ENABLE_FORMS = 2,
    ENABLE_STORAGE = 3
}
export declare enum AnnotationEditorType {
    DISABLE = -1,
    NONE = 0,
    FREETEXT = 3,
    HIGHLIGHT = 9,
    STAMP = 13,
    INK = 15,
    POPUP = 16,
    SIGNATURE = 101,
    COMMENT = 102
}
export declare const AnnotationEditorParamsType: {
    RESIZE: number;
    CREATE: number;
    FREETEXT_SIZE: number;
    FREETEXT_COLOR: number;
    FREETEXT_OPACITY: number;
    INK_COLOR: number;
    INK_THICKNESS: number;
    INK_OPACITY: number;
    HIGHLIGHT_COLOR: number;
    HIGHLIGHT_DEFAULT_COLOR: number;
    HIGHLIGHT_THICKNESS: number;
    HIGHLIGHT_FREE: number;
    HIGHLIGHT_SHOW_ALL: number;
    DRAW_STEP: number;
};
export type AnnotationEditorTypeValue = -1 | 0 | 3 | 9 | 13 | 15 | 16;
export type InkPaths = {
    lines: Array<Array<number>>;
    points: Array<Array<number>>;
};
export type InkEditorAnnotation = {
    annotationType: 15;
    color: Array<number>;
    thickness: number;
    opacity: number;
    paths: InkPaths;
    pageIndex: number;
    rect: Array<number>;
    rotation: 0 | 90 | 180 | 270;
    isCopy?: boolean;
};
export type FreeTextEditorAnnotation = {
    annotationType: 3;
    color: Array<number>;
    fontSize: number;
    value: string;
    pageIndex: number;
    rect: Array<number>;
    rotation: 0 | 90 | 180 | 270;
    isCopy?: boolean;
};
export type StampEditorAnnotation = {
    annotationType: 13;
    pageIndex: number;
    bitmapUrl: string | Blob;
    rect: Array<number>;
    rotation: 0 | 90 | 180 | 270;
    isCopy?: boolean;
};
export type HighlightEditorAnnotation = {
    annotationType: 9;
    color: Array<number>;
    opacity: number;
    thickness: number;
    quadPoints?: any;
    outlines?: Array<Array<number>>;
    pageIndex: number;
    rect: Array<number>;
    rotation: 0 | 90 | 180 | 270;
    isCopy?: boolean;
};
export type PopupEditorAnnotation = {
    annotationType: 16;
    content: string;
    pageIndex: number;
    rect: Array<number>;
    rotation: 0 | 90 | 180 | 270;
    isCopy?: boolean;
};
export type EditorAnnotation = InkEditorAnnotation | FreeTextEditorAnnotation | StampEditorAnnotation | HighlightEditorAnnotation | PopupEditorAnnotation;
