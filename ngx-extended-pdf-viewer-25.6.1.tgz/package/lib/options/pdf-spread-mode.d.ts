export declare enum SpreadMode {
    UNKNOWN = -1,
    NONE = 0,
    ODD = 1,
    EVEN = 2
}
