export interface PDFAttachmentViewer {
}
