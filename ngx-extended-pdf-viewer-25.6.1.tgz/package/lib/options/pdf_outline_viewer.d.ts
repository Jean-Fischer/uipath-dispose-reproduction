export interface PDFOutlineViewer {
}
