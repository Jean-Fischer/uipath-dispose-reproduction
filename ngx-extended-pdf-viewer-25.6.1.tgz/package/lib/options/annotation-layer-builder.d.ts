import { AnnotationStorage } from './pdf-annotation-storage';
import { PageViewport } from './pdf-page-view-port';
import { PDFPageProxy } from './pdf-viewer-application';
export type AnnotationLayerBuilderOptions = {
    pdfPage: PDFPageProxy;
    annotationStorage?: AnnotationStorage | undefined;
    /**
     * - Path for image resources, mainly
     * for annotation icons. Include trailing slash.
     */
    imageResourcesPath?: string | undefined;
    renderForms: boolean;
    linkService: any;
    downloadManager?: any | undefined;
    enableScripting?: boolean | undefined;
    hasJSActionsPromise?: Promise<boolean> | undefined;
    fieldObjectsPromise?: Promise<{
        [x: string]: Object[];
    } | null> | undefined;
    annotationCanvasMap?: Map<string, HTMLCanvasElement> | undefined;
    accessibilityManager?: any | undefined;
    annotationEditorUIManager?: any | undefined;
    onAppend?: Function | undefined;
};
export type AnnotationLayerBuilderRenderOptions = {
    viewport: PageViewport;
    /**
     * - The default value is "display".
     */
    intent?: string | undefined;
    structTreeLayer?: any | undefined;
};
export interface AnnotationLayerBuilder {
    pageDiv: HTMLDivElement;
    pdfPage: PDFPageProxy;
    annotationStorage: AnnotationStorage;
    imageResourcesPath: string;
    renderForms: boolean;
    enableScripting: boolean;
    annotationCanvasMap: Map<string, HTMLCanvasElement>;
    render({ viewport, intent, structTreeLayer }: AnnotationLayerBuilderRenderOptions): Promise<void>;
}
