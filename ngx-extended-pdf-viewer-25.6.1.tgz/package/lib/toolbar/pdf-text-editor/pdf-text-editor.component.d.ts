import { ChangeDetectorRef } from '@angular/core';
import { FocusManagementService } from '../../focus-management.service';
import { PDFNotificationService } from '../../pdf-notification-service';
import { ResponsiveVisibility } from '../../responsive-visibility';
import * as i0 from "@angular/core";
export declare class PdfTextEditorComponent {
    private cdr;
    private focusManagement;
    show: ResponsiveVisibility;
    isSelected: boolean;
    private PDFViewerApplication;
    constructor(notificationService: PDFNotificationService, cdr: ChangeDetectorRef, focusManagement: FocusManagementService);
    private onPdfJsInit;
    onClick(event: PointerEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<PdfTextEditorComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PdfTextEditorComponent, "pdf-text-editor", never, { "show": { "alias": "show"; "required": false; }; }, {}, never, never, false, never>;
}
