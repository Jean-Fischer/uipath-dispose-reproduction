import { ResponsiveVisibility } from '../../responsive-visibility';
import * as i0 from "@angular/core";
export declare class PdfEditorComponent {
    showCommentEditor: ResponsiveVisibility;
    showDrawEditor: ResponsiveVisibility;
    showHighlightEditor: ResponsiveVisibility;
    showTextEditor: ResponsiveVisibility;
    showSignatureEditor: ResponsiveVisibility;
    showStampEditor: ResponsiveVisibility;
    static ɵfac: i0.ɵɵFactoryDeclaration<PdfEditorComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PdfEditorComponent, "pdf-editor", never, { "showCommentEditor": { "alias": "showCommentEditor"; "required": false; }; "showDrawEditor": { "alias": "showDrawEditor"; "required": false; }; "showHighlightEditor": { "alias": "showHighlightEditor"; "required": false; }; "showTextEditor": { "alias": "showTextEditor"; "required": false; }; "showSignatureEditor": { "alias": "showSignatureEditor"; "required": false; }; "showStampEditor": { "alias": "showStampEditor"; "required": false; }; }, {}, never, never, false, never>;
}
