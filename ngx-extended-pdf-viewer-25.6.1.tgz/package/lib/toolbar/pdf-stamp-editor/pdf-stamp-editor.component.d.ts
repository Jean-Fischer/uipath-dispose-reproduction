import { ChangeDetectorRef } from '@angular/core';
import { PositioningService } from '../../dynamic-css/positioning.service';
import { FocusManagementService } from '../../focus-management.service';
import { PDFNotificationService } from '../../pdf-notification-service';
import { ResponsiveVisibility } from '../../responsive-visibility';
import * as i0 from "@angular/core";
export declare class PdfStampEditorComponent {
    private cdr;
    private positioningService;
    private focusManagement;
    show: ResponsiveVisibility;
    isSelected: boolean;
    private PDFViewerApplication;
    get pdfJsVersion(): string;
    constructor(notificationService: PDFNotificationService, cdr: ChangeDetectorRef, positioningService: PositioningService, focusManagement: FocusManagementService);
    private onPdfJsInit;
    onClick(event: PointerEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<PdfStampEditorComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PdfStampEditorComponent, "pdf-stamp-editor", never, { "show": { "alias": "show"; "required": false; }; }, {}, never, never, false, never>;
}
