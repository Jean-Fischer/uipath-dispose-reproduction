import { ResponsiveVisibility } from '../../responsive-visibility';
import { PDFNotificationService } from '../../pdf-notification-service';
import * as i0 from "@angular/core";
export declare class PdfMoveDownComponent {
    private notificationService;
    showMoveDownButton: ResponsiveVisibility;
    private PDFViewerApplication;
    constructor(notificationService: PDFNotificationService);
    movePageDown: () => void;
    static ɵfac: i0.ɵɵFactoryDeclaration<PdfMoveDownComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PdfMoveDownComponent, "pdf-move-down", never, { "showMoveDownButton": { "alias": "showMoveDownButton"; "required": false; }; }, {}, never, never, false, never>;
}
