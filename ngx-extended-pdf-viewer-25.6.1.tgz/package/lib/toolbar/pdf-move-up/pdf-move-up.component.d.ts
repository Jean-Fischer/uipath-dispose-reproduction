import { ResponsiveVisibility } from '../../responsive-visibility';
import { PDFNotificationService } from '../../pdf-notification-service';
import * as i0 from "@angular/core";
export declare class PdfMoveUpComponent {
    private notificationService;
    showMoveUpButton: ResponsiveVisibility;
    private PDFViewerApplication;
    constructor(notificationService: PDFNotificationService);
    movePageUp: () => void;
    static ɵfac: i0.ɵɵFactoryDeclaration<PdfMoveUpComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PdfMoveUpComponent, "pdf-move-up", never, { "showMoveUpButton": { "alias": "showMoveUpButton"; "required": false; }; }, {}, never, never, false, never>;
}
