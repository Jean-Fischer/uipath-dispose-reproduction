import * as i0 from "@angular/core";
export declare class AddSignatureDialogComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<AddSignatureDialogComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AddSignatureDialogComponent, "pdf-add-signature-dialog", never, {}, {}, never, never, false, never>;
}
