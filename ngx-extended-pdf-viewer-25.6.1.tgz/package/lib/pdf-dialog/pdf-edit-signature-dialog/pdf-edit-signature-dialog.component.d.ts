import * as i0 from "@angular/core";
export declare class EditSignatureDialogComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<EditSignatureDialogComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<EditSignatureDialogComponent, "pdf-edit-signature-dialog", never, {}, {}, never, never, false, never>;
}
